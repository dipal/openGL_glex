#include "shapeinterface.h"

ShapeInterface::ShapeInterface()
{
}
