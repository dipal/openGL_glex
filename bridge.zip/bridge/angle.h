#ifndef ANGLE_H
#define ANGLE_H

class angle
{
public:
    angle();
    angle(double ix,double iy=0,double iz=0);

    double x,y,z;
};

#endif // ANGLE_H
