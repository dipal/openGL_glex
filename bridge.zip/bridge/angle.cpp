#include "angle.h"

angle::angle()
{
    x=y=z=0;
}

angle::angle(double ix, double iy, double iz) : x(ix),y(iy),z(iz) {

}
